// API utility functions with Authorization Bearer token and SSO token
import { PublicClientApplication } from '@azure/msal-browser';

const API_BASE_URL = 'http://localhost:3000/api';
const AUTH_TOKEN = 'Qw8!zR2@pL6';

// MSAL instance for getting SSO tokens
let msalInstance: PublicClientApplication | null = null;

// Function to set MSAL instance (called from SSOProvider)
export const setMsalInstance = (instance: PublicClientApplication) => {
  msalInstance = instance;
  console.log('MSAL instance set in api.ts');
};

// Function to get SSO token
const getSSOToken = async (): Promise<string | null> => {
  try {
    console.log('Getting SSO token...');
    
    if (!msalInstance) {
      console.warn('MSAL instance not available');
      return null;
    }

    const accounts = msalInstance.getAllAccounts();
    console.log('Found accounts:', accounts.length);
    
    if (accounts.length === 0) {
      console.warn('No accounts found - user not logged in');
      return null;
    }

    console.log('Acquiring token silently...');
    const response = await msalInstance.acquireTokenSilent({
      scopes: ['User.Read'],
      account: accounts[0]
    });

    console.log('SSO token acquired successfully');
    return response.accessToken;
  } catch (error) {
    console.error('Failed to get SSO token:', error);
    return null;
  }
};

// Helper function to create headers with Authorization and SSO token
const createHeaders = async (contentType?: string): Promise<HeadersInit> => {
  const headers: HeadersInit = {};
  
  // Keep existing static token
  headers['Authorization'] = `Bearer ${AUTH_TOKEN}`;
  
  // Add SSO token
  const ssoToken = await getSSOToken();
  if (ssoToken) {
    headers['X-SSO-Token'] = ssoToken;
    console.log('SSO token added to headers');
  } else {
    console.warn('No SSO token available - user may not be logged in');
  }
  
  if (contentType) {
    headers['Content-Type'] = contentType;
  }
  
  console.log('Headers created:', Object.keys(headers));
  return headers;
};

// GET request helper
export const apiGet = async (endpoint: string, params?: Record<string, any>): Promise<any> => {
  let url = `${API_BASE_URL}${endpoint}`;
  
  // Add query parameters if provided
  if (params && Object.keys(params).length > 0) {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        queryParams.append(key, value.toString());
      }
    });
    if (queryParams.toString()) {
      url += `?${queryParams.toString()}`;
    }
  }
  
  const response = await fetch(url, {
    method: 'GET',
    headers: await createHeaders()
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// POST request helper
export const apiPost = async (endpoint: string, data: any, contentType: string = 'application/json'): Promise<any> => {
  const body = contentType === 'application/json' ? JSON.stringify(data) : data;
  
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: await createHeaders(contentType),
    body
  });
  
  if (!response.ok) {
    // Try to get the error message from the response
    let errorMessage = `HTTP error! status: ${response.status}`;
    try {
      const errorData = await response.json();
      if (errorData.message) {
        errorMessage = `${errorMessage} - ${errorData.message}`;
      }
    } catch (e) {
      // If we can't parse the response, use the status text
      errorMessage = `${errorMessage} - ${response.statusText}`;
    }
    throw new Error(errorMessage);
  }
  
  return response.json();
};

// PUT request helper
export const apiPut = async (endpoint: string, data: any, contentType: string = 'application/json'): Promise<any> => {
  const body = contentType === 'application/json' ? JSON.stringify(data) : data;
  
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'PUT',
    headers: await createHeaders(contentType),
    body
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// PATCH request helper
export const apiPatch = async (endpoint: string, data: any): Promise<any> => {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'PATCH',
    headers: await createHeaders('application/json'),
    body: JSON.stringify(data)
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// DELETE request helper
export const apiDelete = async (endpoint: string): Promise<any> => {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'DELETE',
    headers: await createHeaders()
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// POST request helper with query parameters
export const apiPostWithParams = async (endpoint: string, params?: Record<string, any>, data?: any): Promise<any> => {
  let url = `${API_BASE_URL}${endpoint}`;
  
  // Add query parameters if provided
  if (params && Object.keys(params).length > 0) {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        queryParams.append(key, value.toString());
      }
    });
    if (queryParams.toString()) {
      url += `?${queryParams.toString()}`;
    }
  }
  
  // Ensure we always have a valid body for POST requests
  const requestBody = data || {};
  
  const response = await fetch(url, {
    method: 'POST',
    headers: await createHeaders('application/json'),
    body: JSON.stringify(requestBody)
  });
  
  if (!response.ok) {
    // Try to get the error message from the response
    let errorMessage = `HTTP error! status: ${response.status}`;
    try {
      const errorData = await response.json();
      if (errorData.message) {
        errorMessage = `${errorMessage} - ${errorData.message}`;
      }
    } catch (e) {
      // If we can't parse the response, use the status text
      errorMessage = `${errorMessage} - ${response.statusText}`;
    }
    throw new Error(errorMessage);
  }
  
  return response.json();
};

// For FormData requests (no Content-Type header needed)
export const apiPostFormData = async (endpoint: string, formData: FormData): Promise<Response> => {
  const headers = await createHeaders();
  // Remove Content-Type for FormData (browser will set it with boundary)
  const formDataHeaders = { ...headers } as any;
  delete formDataHeaders['Content-Type'];
  
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: formDataHeaders,
    body: formData
  });
  
  // Return the response object instead of throwing an error
  // This allows the calling code to handle validation errors properly
  return response;
};

export const apiPutFormData = async (endpoint: string, formData: FormData): Promise<Response> => {
  const headers = await createHeaders();
  // Remove Content-Type for FormData (browser will set it with boundary)
  const formDataHeaders = { ...headers } as any;
  delete formDataHeaders['Content-Type'];
  
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    method: 'PUT',
    headers: formDataHeaders,
    body: formData
  });
  
  // Return the response object instead of throwing an error
  // This allows the calling code to handle validation errors properly
  return response;
}; 