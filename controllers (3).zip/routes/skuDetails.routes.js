const { getSkuDetailsByCMCodeController, getAllSkuDetailsController, updateIsActiveStatusController, getActiveYearsController, getAllSkuDescriptionsController, insertSkuDetailController, updateSkuDetailBySkuCodeController, getAllMasterDataController, getConsolidatedDashboardController, toggleUniversalStatusController, testMappingTableStatus, exportExcelController, skuComponentMappingController } = require('../controllers/controller.getSkuDetails');
const { ssoTokenMiddleware } = require('../middleware/middleware.sso');

async function skuDetailsRoutes(fastify, options) {
  // Protected routes - requires SSO token
  fastify.get('/api/sku-details', {
    preHandler: ssoTokenMiddleware
  }, getAllSkuDetailsController);
  
  fastify.get('/api/sku-details/:cm_code', {
    preHandler: ssoTokenMiddleware
  }, getSkuDetailsByCMCodeController);
  
  fastify.patch('/api/sku-details/:id/is-active', {
    preHandler: ssoTokenMiddleware
  }, updateIsActiveStatusController);
  
  fastify.get('/api/sku-details-active-years', {
    preHandler: ssoTokenMiddleware
  }, getActiveYearsController);
  
  fastify.get('/api/sku-descriptions', {
    preHandler: ssoTokenMiddleware
  }, getAllSkuDescriptionsController);
  
  fastify.post('/api/sku-details/add', {
    preHandler: ssoTokenMiddleware
  }, insertSkuDetailController);
  
  fastify.put('/api/sku-details/update/:sku_code', {
    preHandler: ssoTokenMiddleware
  }, updateSkuDetailBySkuCodeController);
  
  // Master Data API - Get all master data in one call
  fastify.get('/api/get-masterdata', {
    preHandler: ssoTokenMiddleware
  }, getAllMasterDataController);

  // Consolidated Dashboard API - Get multiple data types in one call
  fastify.get('/api/cm-dashboard/:cmCode', {
    preHandler: ssoTokenMiddleware
  }, getConsolidatedDashboardController);

  // Universal Status Toggle API - Handle both SKU and Component status changes
  fastify.patch('/api/toggle-status', {
    preHandler: ssoTokenMiddleware
  }, toggleUniversalStatusController);

  // Test endpoint to check mapping table status
  fastify.get('/api/test-mapping-table', {
    preHandler: ssoTokenMiddleware
  }, testMappingTableStatus);

  // Export Excel API
  fastify.post('/api/export-excel', {
    preHandler: ssoTokenMiddleware
  }, exportExcelController);

  // SKU Component Mapping API - Get mapping data between SKU and components
  fastify.post('/api/sku-component-mapping', {
    preHandler: ssoTokenMiddleware
  }, skuComponentMappingController);
}

module.exports = skuDetailsRoutes; 