const { getComponentAuditLogByComponentIdHandler } = require('../controllers/controller.getComponentAuditLogByComponentId');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

/**
 * Routes for component audit log by component_id
 */
async function routes(fastify, options) {
  // GET component audit log by component_id - Protected route
  fastify.get('/api/component-audit-log/:componentId', {
    preHandler: bearerTokenMiddleware,
    schema: {
      params: {
        type: 'object',
        required: ['componentId'],
        properties: {
          componentId: {
            type: 'string',
            description: 'Component ID to fetch audit log for'
          }
        }
      },
      response: {
        200: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            data: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  id: { type: 'integer' },
                  cm_code: { type: 'string' },
                  sku_code: { type: 'string' },
                  component_code: { type: 'string' },
                  version: { type: 'integer' },
                  component_packaging_type_id: { type: 'string' },
                  period_id: { type: 'integer' },
                  component_valid_from: { type: 'string', format: 'date-time' },
                  component_valid_to: { type: 'string', format: 'date-time' },
                  created_by: { type: 'string' },
                  action_type: { type: 'string' },
                  action_reason: { type: 'string' },
                  old_values: { type: 'string' },
                  new_values: { type: 'string' },
                  changed_by: { type: 'string' },
                  changed_at: { type: 'string', format: 'date-time' },
                  change_summary: { type: 'string' },
                  componentvaliditydatefrom: { type: 'string', format: 'date-time' },
                  componentvaliditydateto: { type: 'string', format: 'date-time' },
                  componentid: { type: 'integer' }
                }
              }
            },
            count: { type: 'integer' }
          }
        },
        400: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' }
          }
        },
        404: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            data: { type: 'array' }
          }
        },
        500: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' }
          }
        }
      }
    }
  }, getComponentAuditLogByComponentIdHandler);
}

module.exports = routes; 