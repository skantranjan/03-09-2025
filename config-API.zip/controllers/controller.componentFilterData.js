const db = require('../config/db.config');
const { insertComponentAuditLog } = require('../models/model.addComponentAuditLog');

const getFilteredComponentData = async (request, reply) => {
    try {
        const { 
            cm_code, 
            period, 
            packaging_type, 
            component_packaging_type, 
            sku, 
            component_fields, 
            exclude_external,
            generate_pdf = false,
            audit_log = true
        } = request.body || request.query;

        // Validate mandatory cm_code
        if (!cm_code) {
            return reply.code(400).send({
                success: false,
                message: 'cm_code is required'
            });
        }

        // Build dynamic WHERE clause for the comprehensive query
        let whereConditions = ['scm.cm_code = $1'];
        let queryParams = [cm_code];
        let paramIndex = 2;

        // Add period filter (mandatory for audit logging and PDF generation)
        if (period) {
            whereConditions.push(`scm.period_id = $${paramIndex}`);
            queryParams.push(period);
            paramIndex++;
        } else {
            // Default to period 3 if not specified (as per your requirement)
            whereConditions.push(`scm.period_id = $${paramIndex}`);
            queryParams.push(3);
            paramIndex++;
        }

        // Add optional filters
        if (packaging_type) {
            whereConditions.push(`scm.packaging_type_id = $${paramIndex}`);
            queryParams.push(packaging_type);
            paramIndex++;
        }

        if (component_packaging_type) {
            whereConditions.push(`scm.component_packaging_type_id = $${paramIndex}`);
            queryParams.push(component_packaging_type);
            paramIndex++;
        }

        if (sku) {
            whereConditions.push(`scm.sku_code = $${paramIndex}`);
            queryParams.push(sku);
            paramIndex++;
        }

        if (component_fields) {
            whereConditions.push(`scm.component_code = $${paramIndex}`);
            queryParams.push(component_fields);
            paramIndex++;
        }

        if (exclude_external !== undefined && exclude_external !== null) {
            whereConditions.push(`scm.exclude_external = $${paramIndex}`);
            queryParams.push(exclude_external);
            paramIndex++;
        }

        // Build the complete comprehensive query - exactly as specified in your requirements
        const whereClause = whereConditions.join(' AND ');
        
        const comprehensiveQuery = `
            SELECT DISTINCT ON (scm.cm_code, scm.sku_code, scm.component_code, scm.version)
                scm.cm_code AS "CM Code",
                scm.sku_code AS "CM Description",
                scm.sku_code AS "SKU Code",
                sd.sku_description AS "SKU Description",
                sd.purchased_quantity AS "Purchased Quantity",
                sd.sku_reference AS "Reference SKU",
                sd.sku_reference_check AS "SKU Reference Check",
                sd.formulation_reference AS "Formulation Reference",
                cd.material_type_id AS "Material Type",
                cd.components_reference AS "Components Reference",
                cd.component_code AS "Component Code",
                cd.component_description AS "Component Description",
                cd.component_valid_from AS "Component Validity From",
                cd.component_valid_to AS "Component Validity To",
                cd.component_material_group AS "Component Material Group",
                cd.component_quantity AS "Component Quantity",
                cd.component_uom_id AS "Component Unit of Measure",
                cd.component_base_quantity AS "Component Base Quantity",
                cd.component_base_uom_id AS "Component Base Unit of Measure",
                cd.percent_w_w AS "Component %w/w",
                cd.evidence AS "Evidence",
                scm.component_packaging_type_id AS "Component Packaging Type",
                cd.helper_column AS "Component Packaging Material",
                scm.sku_code AS "Helper Column",
                cd.component_unit_weight AS "Component Unit Weight",
                cd.weight_unit_measure_id AS "Weight Unit Measure",
                cd.percent_mechanical_pcr_content AS "% Mechanical Post-Consumer Recycled Content(inc Chemical)",
                cd.percent_mechanical_pir_content AS "% Mechanical Post-Industiral Recycled Content",
                cd.percent_chemical_recycled_content AS "% Chemical Recycled Content",
                cd.percent_bio_sourced AS "% Bio Sourced",
                cd.material_structure_multimaterials AS "Material Structure-multimaterial only(with % wt)",
                cd.component_packaging_color_opacity AS "Component Packaging Colour",
                cd.component_packaging_level_id AS "Component Packaging Level",
                cd.component_dimensions AS "Component Dimensions",
                cd.packaging_specification_evidence AS "Packaging Specification Evidence",
                cd.evidence_of_recycled_or_bio_source AS "Evidence of Recycled or Bio Source",
                cd.last_update_date AS "Last Update Date"
            FROM 
                public.sdp_sku_component_mapping_details scm
            LEFT JOIN public.sdp_skudetails sd 
                ON scm.sku_code = sd.sku_code AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_component_details cd 
                ON scm.component_code = cd.component_code 
                   AND scm.sku_code = cd.sku_code 
                   AND scm.cm_code = cd.cm_code
            WHERE 
                ${whereClause}
            ORDER BY 
                scm.cm_code, scm.sku_code, scm.component_code, scm.version
        `;

        console.log('Excel Sheet PDF Generation Query:', comprehensiveQuery);
        console.log('Query Parameters:', queryParams);
        console.log('Period ID Filter:', period || 3);

        const result = await db.query(comprehensiveQuery, queryParams);

        // Enhanced audit logging based on period for Excel sheet PDF generation
        if (audit_log && result.rows.length > 0) {
            try {
                const auditData = {
                    cm_code: cm_code,
                    periods: period || 3,
                    component_code: component_fields || 'EXCEL_PDF_QUERY',
                    sku_code: sku || 'MULTIPLE_SKUS',
                    component_description: `Excel sheet PDF generation query executed for CM: ${cm_code}, Period ID: ${period || 3}`,
                    action_type: 'EXPORT',
                    action_reason: 'EXCEL_PDF_GENERATION',
                    old_values: null,
                    new_values: JSON.stringify({
                        query_type: 'excel_pdf_generation',
                        filters_applied: {
                            cm_code,
                            period_id: period || 3,
                            packaging_type,
                            component_packaging_type,
                            sku,
                            component_fields,
                            exclude_external
                        },
                        results_count: result.rows.length,
                        pdf_generation: generate_pdf,
                        excel_sheet_format: true
                    }),
                    changed_by: request.user?.email || 'system',
                    change_summary: `Excel sheet PDF generation query executed for CM ${cm_code} with period_id ${period || 3}, returning ${result.rows.length} components`,
                    created_by: request.user?.email || 'system',
                    created_date: new Date(),
                    last_update_date: new Date()
                };

                await insertComponentAuditLog(auditData);
                console.log('Audit log created successfully for Excel sheet PDF generation query');
            } catch (auditError) {
                console.error('Audit logging failed (non-blocking):', auditError);
                // Continue execution even if audit logging fails
            }
        }

        // Prepare response data with Excel sheet PDF generation focus
        const responseData = {
            success: true,
            message: 'Excel sheet PDF generation data retrieved successfully',
            data: result.rows,
            total_count: result.rows.length,
            query_info: {
                cm_code,
                period_id: period || 3,
                filters_applied: {
                    packaging_type,
                    component_packaging_type,
                    sku,
                    component_fields,
                    exclude_external
                },
                audit_logged: audit_log,
                pdf_ready: generate_pdf,
                excel_sheet_format: true
            },
            excel_pdf_generation: {
                period_id: period || 3,
                cm_code: cm_code,
                component_count: result.rows.length,
                ready_for_pdf: true,
                data_format: 'excel_sheet_compatible'
            }
        };

        // If PDF generation is requested, add PDF generation instructions for Excel sheet
        if (generate_pdf) {
            responseData.pdf_generation = {
                endpoint: '/api/generatepdf',
                method: 'POST',
                required_fields: ['cm_code', 'period_id', 'email'],
                note: 'Use the filtered Excel sheet data above to generate PDF reports',
                excel_sheet_data: true,
                period_id_filter: period || 3
            };
        }

        return reply.send(responseData);

    } catch (error) {
        console.error('Error in getFilteredComponentData for Excel sheet PDF generation:', error);
        return reply.code(500).send({
            success: false,
            message: 'Internal server error while filtering component data for Excel sheet PDF generation',
            error: error.message
        });
    }
};

// Enhanced function for generating PDF from filtered Excel sheet data
const generatePdfFromFilteredData = async (request, reply) => {
    try {
        const { 
            cm_code, 
            period, 
            email,
            filters = {}
        } = request.body;

        // Validate required fields
        if (!cm_code || !period || !email) {
            return reply.code(400).send({
                success: false,
                message: 'cm_code, period (period_id), and email are required for Excel sheet PDF generation'
            });
        }

        // First get the filtered data using the Excel sheet query
        const filterRequest = {
            body: { cm_code, period, ...filters, generate_pdf: true, audit_log: true }
        };
        const mockReply = {
            send: (data) => data,
            code: () => ({ send: (data) => data })
        };

        const filteredData = await getFilteredComponentData(filterRequest, mockReply);

        if (!filteredData.success) {
            return reply.code(400).send({
                success: false,
                message: 'Failed to retrieve filtered Excel sheet data for PDF generation',
                error: filteredData.message
            });
        }

        // Create comprehensive audit log for Excel sheet PDF generation
        try {
            const auditData = {
                cm_code,
                periods: period,
                component_code: 'EXCEL_PDF_GENERATION',
                sku_code: 'MULTIPLE_SKUS',
                component_description: `PDF generated from Excel sheet filtered data for CM: ${cm_code}, Period ID: ${period}`,
                action_type: 'EXPORT',
                action_reason: 'EXCEL_PDF_GENERATION',
                old_values: null,
                new_values: JSON.stringify({
                    export_type: 'excel_sheet_pdf',
                    filters_applied: filters,
                    data_count: filteredData.total_count,
                    recipient_email: email,
                    period_id: period,
                    excel_sheet_format: true
                }),
                changed_by: request.user?.email || 'system',
                change_summary: `Excel sheet PDF generated for CM ${cm_code} with period_id ${period}, containing ${filteredData.total_count} components`,
                created_by: request.user?.email || 'system',
                created_date: new Date(),
                last_update_date: new Date()
            };

            await insertComponentAuditLog(auditData);
            console.log('Audit log created successfully for Excel sheet PDF generation');
        } catch (auditError) {
            console.error('Audit logging failed for Excel sheet PDF generation (non-blocking):', auditError);
        }

        // Return success with Excel sheet data ready for PDF generation
        return reply.send({
            success: true,
            message: 'Excel sheet data prepared for PDF generation',
            data: filteredData.data,
            total_count: filteredData.total_count,
            pdf_generation: {
                status: 'ready',
                next_step: 'Use /api/generatepdf endpoint with this Excel sheet data',
                data_summary: {
                    cm_code,
                    period_id: period,
                    components_count: filteredData.total_count,
                    recipient_email: email,
                    excel_sheet_format: true
                },
                excel_sheet_info: {
                    period_id_filter: period,
                    cm_code: cm_code,
                    data_format: 'excel_sheet_compatible',
                    ready_for_pdf: true
                }
            }
        });

    } catch (error) {
        console.error('Error in generatePdfFromFilteredData for Excel sheet:', error);
        return reply.code(500).send({
            success: false,
            message: 'Internal server error while preparing Excel sheet PDF generation',
            error: error.message
        });
    }
};

// New function specifically for Excel sheet data export
const exportExcelSheetData = async (request, reply) => {
    try {
        const { 
            cm_code, 
            period_id,
            export_format = 'excel'
        } = request.body;

        // Validate required fields
        if (!cm_code || !period_id) {
            return reply.code(400).send({
                success: false,
                message: 'cm_code and period_id are required for Excel sheet export'
            });
        }

        // Execute the exact query you specified for Excel sheet export
        const excelExportQuery = `
            SELECT DISTINCT ON (scm.cm_code, scm.sku_code, scm.component_code, scm.version)
                scm.cm_code AS "CM Code",
                scm.sku_code AS "CM Description",
                scm.sku_code AS "SKU Code",
                sd.sku_description AS "SKU Description",
                sd.purchased_quantity AS "Purchased Quantity",
                sd.sku_reference AS "Reference SKU",
                sd.sku_reference_check AS "SKU Reference Check",
                sd.formulation_reference AS "Formulation Reference",
                cd.material_type_id AS "Material Type",
                cd.components_reference AS "Components Reference",
                cd.component_code AS "Component Code",
                cd.component_description AS "Component Description",
                cd.component_valid_from AS "Component Validity From",
                cd.component_valid_to AS "Component Validity To",
                cd.component_material_group AS "Component Material Group",
                cd.component_quantity AS "Component Quantity",
                cd.component_uom_id AS "Component Unit of Measure",
                cd.component_base_quantity AS "Component Base Quantity",
                cd.component_base_uom_id AS "Component Base Unit of Measure",
                cd.percent_w_w AS "Component %w/w",
                cd.evidence AS "Evidence",
                scm.component_packaging_type_id AS "Component Packaging Type",
                cd.helper_column AS "Component Packaging Material",
                scm.sku_code AS "Helper Column",
                cd.component_unit_weight AS "Component Unit Weight",
                cd.weight_unit_measure_id AS "Weight Unit Measure",
                cd.percent_mechanical_pcr_content AS "% Mechanical Post-Consumer Recycled Content(inc Chemical)",
                cd.percent_mechanical_pir_content AS "% Mechanical Post-Industiral Recycled Content",
                cd.percent_chemical_recycled_content AS "% Chemical Recycled Content",
                cd.percent_bio_sourced AS "% Bio Sourced",
                cd.material_structure_multimaterials AS "Material Structure-multimaterial only(with % wt)",
                cd.component_packaging_color_opacity AS "Component Packaging Colour",
                cd.component_packaging_level_id AS "Component Packaging Level",
                cd.component_dimensions AS "Component Dimensions",
                cd.packaging_specification_evidence AS "Packaging Specification Evidence",
                cd.evidence_of_recycled_or_bio_source AS "Evidence of Recycled or Bio Source",
                cd.last_update_date AS "Last Update Date"
            FROM 
                public.sdp_sku_component_mapping_details scm
            LEFT JOIN public.sdp_skudetails sd 
                ON scm.sku_code = sd.sku_code AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_component_details cd 
                ON scm.component_code = cd.component_code 
                   AND scm.sku_code = cd.sku_code 
                   AND scm.cm_code = cd.cm_code
            WHERE 
                scm.cm_code = $1 AND scm.period_id = $2
            ORDER BY 
                scm.cm_code, scm.sku_code, scm.component_code, scm.version
        `;

        console.log('Excel Sheet Export Query:', excelExportQuery);
        console.log('Export Parameters:', [cm_code, period_id]);

        const result = await db.query(excelExportQuery, [cm_code, period_id]);

        // Audit log for Excel sheet export
        try {
            const auditData = {
                cm_code,
                periods: period_id,
                component_code: 'EXCEL_SHEET_EXPORT',
                sku_code: 'MULTIPLE_SKUS',
                component_description: `Excel sheet export executed for CM: ${cm_code}, Period ID: ${period_id}`,
                action_type: 'EXPORT',
                action_reason: 'EXCEL_SHEET_EXPORT',
                old_values: null,
                new_values: JSON.stringify({
                    export_type: 'excel_sheet',
                    period_id: period_id,
                    cm_code: cm_code,
                    data_count: result.rows.length,
                    export_format: export_format
                }),
                changed_by: request.user?.email || 'system',
                change_summary: `Excel sheet export for CM ${cm_code} with period_id ${period_id}, exported ${result.rows.length} components`,
                created_by: request.user?.email || 'system',
                created_date: new Date(),
                last_update_date: new Date()
            };

            await insertComponentAuditLog(auditData);
            console.log('Audit log created successfully for Excel sheet export');
        } catch (auditError) {
            console.error('Audit logging failed for Excel sheet export (non-blocking):', auditError);
        }

        return reply.send({
            success: true,
            message: 'Excel sheet data exported successfully',
            data: result.rows,
            total_count: result.rows.length,
            export_info: {
                cm_code,
                period_id,
                export_format,
                excel_sheet_ready: true,
                data_format: 'excel_sheet_compatible'
            }
        });

    } catch (error) {
        console.error('Error in exportExcelSheetData:', error);
        return reply.code(500).send({
            success: false,
            message: 'Internal server error while exporting Excel sheet data',
            error: error.message
        });
    }
};

module.exports = {
    getFilteredComponentData,
    generatePdfFromFilteredData,
    exportExcelSheetData
};
