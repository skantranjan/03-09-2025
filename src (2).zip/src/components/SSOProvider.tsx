import React, { ReactNode, useEffect } from 'react';
import { MsalProvider } from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';
import { msalConfig } from '../config/msalConfig';
import { setMsalInstance } from '../utils/api';

// Create MSAL instance
const msalInstance = new PublicClientApplication(msalConfig);

interface SSOProviderProps {
  children: ReactNode;
}

const SSOProvider: React.FC<SSOProviderProps> = ({ children }) => {
  useEffect(() => {
    // Initialize MSAL instance
    msalInstance.initialize().then(() => {
      console.log('MSAL instance initialized');
      // Set the MSAL instance in api.ts so it can be used for SSO tokens
      setMsalInstance(msalInstance);
    }).catch((error) => {
      console.error('Failed to initialize MSAL:', error);
    });
  }, []);

  return (
    <MsalProvider instance={msalInstance}>
      {children}
    </MsalProvider>
  );
};

export default SSOProvider;
