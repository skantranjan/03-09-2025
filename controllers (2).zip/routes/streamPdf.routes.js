const { streamPdfController } = require('../controllers/controller.streamPdf');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

async function streamPdfRoutes(fastify, options) {
  // Protected route - requires Bearer token
  // Stream PDF file from Azure Blob Storage
  fastify.get('/api/stream-pdf/:agreementId', {
    preHandler: bearerTokenMiddleware
  }, streamPdfController);
}

module.exports = streamPdfRoutes;
