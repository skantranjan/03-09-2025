const { updateSkuApprovalController } = require('../controllers/controller.skuApproval');
const { ssoTokenMiddleware } = require('../middleware/middleware.sso');

async function skuApprovalRoutes(fastify, options) {
  // Protected route - requires SSO token
  fastify.post('/api/skuapproval', {
    preHandler: ssoTokenMiddleware
  }, updateSkuApprovalController);
}

module.exports = skuApprovalRoutes;
