const { BlobServiceClient } = require('@azure/storage-blob');
const { AzureCliCredential } = require('@azure/identity');

/**
 * Controller to stream PDF files from Azure Blob Storage
 * This allows secure access to PDFs without making the storage account public
 */
async function streamPdfController(request, reply) {
  try {
    const { agreementId } = request.params;
    
    if (!agreementId || agreementId.trim() === '') {
      return reply.code(400).send({ 
        success: false, 
        message: 'Agreement ID is required' 
      });
    }

    console.log('🔍 Streaming PDF for agreement ID:', agreementId);

    // Get blob URL from database first
    const pool = require('../config/db.config');
    const result = await pool.query(`
      SELECT signed_pdf_url, cm_code, periods, email
      FROM public.agreements 
      WHERE agreement_id = $1
    `, [agreementId]);

    if (result.rows.length === 0) {
      return reply.code(404).send({ 
        success: false, 
        message: 'Agreement not found' 
      });
    }

    const agreement = result.rows[0];
    
    if (!agreement.signed_pdf_url) {
      return reply.code(404).send({ 
        success: false, 
        message: 'PDF not available for this agreement' 
      });
    }

    console.log('📄 Found agreement:', {
      agreementId,
      cm_code: agreement.cm_code,
      periods: agreement.periods,
      hasPdfUrl: !!agreement.signed_pdf_url
    });

    // Extract blob name from the URL
    const blobUrl = agreement.signed_pdf_url;
    const urlParts = blobUrl.split('/');
    const blobName = urlParts.slice(4).join('/'); // Remove https://account.blob.core.windows.net/container/
    
    console.log('📦 Extracted blob name:', blobName);

    // Azure configuration
    const accountName = process.env['AZURE-STORAGE-ACCOUNT'];
    const containerName = process.env['AZURE-CONTAINER-NAME-ADOBE'];
    
    if (!accountName || !containerName) {
      throw new Error('Azure storage configuration is missing');
    }
    
    const blobServiceUrl = `https://${accountName}.blob.core.windows.net`;
    
    // Create blob service client
    let blobServiceClient;
    if (process.env['NODE-ENV'] === 'production' && process.env['AZURE-STORAGE-CONNECTION-STRING']) {
      console.log('🔑 Using Azure Storage Connection String');
      blobServiceClient = BlobServiceClient.fromConnectionString(process.env['AZURE-STORAGE-CONNECTION-STRING']);
    } else {
      console.log('🔑 Using Azure Credentials');
      const credential = new AzureCliCredential();
      blobServiceClient = new BlobServiceClient(blobServiceUrl, credential);
    }

    // Get container and blob clients
    const containerClient = blobServiceClient.getContainerClient(containerName);
    const blockBlobClient = containerClient.getBlockBlobClient(blobName);

    // Check if blob exists
    const exists = await blockBlobClient.exists();
    if (!exists) {
      return reply.code(404).send({ 
        success: false, 
        message: 'PDF file not found in storage' 
      });
    }

    // Get blob properties
    const properties = await blockBlobClient.getProperties();
    const contentType = properties.contentType || 'application/pdf';
    const contentLength = properties.contentLength;

    console.log('📊 Blob properties:', {
      contentType,
      contentLength,
      lastModified: properties.lastModified
    });

    // Set response headers
    reply.header('Content-Type', contentType);
    reply.header('Content-Length', contentLength);
    reply.header('Content-Disposition', `inline; filename="agreement_${agreementId}.pdf"`);
    reply.header('Cache-Control', 'private, max-age=3600'); // Cache for 1 hour
    reply.header('X-Agreement-ID', agreementId);
    reply.header('X-CM-Code', agreement.cm_code);
    reply.header('X-Period', agreement.periods);

    // Stream the blob to the response
    const downloadResponse = await blockBlobClient.download();
    
    // Pipe the readable stream to the response
    downloadResponse.readableStreamBody.pipe(reply.raw);

    console.log('✅ PDF streaming started for agreement:', agreementId);

  } catch (error) {
    console.error('❌ Error streaming PDF:', error);
    request.log.error(error);
    
    if (!reply.sent) {
      reply.code(500).send({ 
        success: false, 
        message: 'Failed to stream PDF file', 
        error: error.message 
      });
    }
  }
}

module.exports = { streamPdfController };
