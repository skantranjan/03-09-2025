/**
 * SSO Token Validation Middleware
 * Validates X-SSO-Token from headers via GraphQL API
 */

const axios = require('axios');

// Microsoft Graph API Configuration
const MICROSOFT_GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0';

/**
 * Microsoft Graph API endpoints
 */
const GRAPH_ENDPOINTS = {
  // Get current user info
  GET_CURRENT_USER: '/me'
};

/**
 * SSO Token Middleware
 * @param {Object} request - Fastify request object
 * @param {Object} reply - Fastify reply object
 * @param {Function} done - Fastify done callback
 */
async function ssoTokenMiddleware(request, reply, done) {
  try {
    // 1. Extract X-SSO-Token from headers
    const ssoToken = request.headers['x-sso-token'];
    
    if (!ssoToken) {
      return reply.code(401).send({
        success: false,
        message: 'Missing X-SSO-Token header',
        error: 'AUTHENTICATION_REQUIRED'
      });
    }

    // 2. Validate token format (basic check)
    if (typeof ssoToken !== 'string' || ssoToken.trim().length === 0) {
      return reply.code(401).send({
        success: false,
        message: 'Invalid SSO token format',
        error: 'INVALID_TOKEN_FORMAT'
      });
    }

    // 3. Call Air Portal API to validate token
    const validationResult = await validateTokenWithAirPortal(ssoToken);
    
    if (!validationResult.isValid) {
      return reply.code(401).send({
        success: false,
        message: validationResult.error?.message || 'Invalid SSO token',
        error: validationResult.error?.code || 'TOKEN_VALIDATION_FAILED'
      });
    }

    // 4. Check if user is active
    if (!validationResult.user.isActive) {
      return reply.code(403).send({
        success: false,
        message: 'User account is inactive',
        error: 'USER_INACTIVE'
      });
    }

    // 5. Attach user information to request object
    request.user = {
      id: validationResult.user.id,
      email: validationResult.user.email,
      username: validationResult.user.username,
      role: validationResult.user.role,
      permissions: validationResult.user.permissions,
      isActive: validationResult.user.isActive,
      ssoToken: ssoToken // Keep original token for potential use
    };

    // 6. Log successful authentication (optional)
    console.log(`✅ SSO Authentication successful for user: ${request.user.email}`);

    // 7. Continue to route handler
    done();

  } catch (error) {
    console.error('❌ SSO Middleware Error:', error);
    
    // Handle different types of errors
    if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
      return reply.code(503).send({
        success: false,
        message: 'SSO service unavailable',
        error: 'SSO_SERVICE_UNAVAILABLE'
      });
    }
    
    if (error.response?.status === 401) {
      return reply.code(401).send({
        success: false,
        message: 'SSO token validation failed',
        error: 'TOKEN_VALIDATION_FAILED'
      });
    }

    // Generic server error
    return reply.code(500).send({
      success: false,
      message: 'Internal server error during authentication',
      error: 'AUTHENTICATION_ERROR'
    });
  }
}

/**
 * Validate SSO token with Air Portal API
 * @param {string} token - SSO token to validate
 * @returns {Promise<Object>} Validation result
 */
async function validateTokenWithAirPortal(token) {
  try {
    // Microsoft Graph API endpoint
    const endpoint = `${MICROSOFT_GRAPH_ENDPOINT}${GRAPH_ENDPOINTS.GET_CURRENT_USER}`;

    try {
      console.log(`🔍 Validating token with Microsoft Graph API: ${endpoint}`);
      
      const response = await axios.get(endpoint, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'User-Agent': 'Sustainability-API/1.0'
        },
        timeout: 10000 // 10 second timeout
      });

      // If we get a successful response, the token is valid
      if (response.status === 200 && response.data) {
        console.log('✅ Microsoft Graph validation successful');
        
        // Extract user information from Microsoft Graph response
        const userData = response.data;
        
        return {
          isValid: true,
          user: {
            id: userData.id,
            email: userData.mail || userData.userPrincipalName,
            username: userData.displayName,
            role: 'user', // Microsoft Graph doesn't provide role by default
            permissions: [],
            isActive: true
          }
        };
      }
    } catch (error) {
      console.log(`❌ Microsoft Graph API failed:`, error.response?.status, error.message);
      
      return {
        isValid: false,
        error: {
          code: 'TOKEN_VALIDATION_FAILED',
          message: 'Token validation failed with Microsoft Graph API'
        }
      };
    }

  } catch (error) {
    console.error('Air Portal API Error:', error);
    
    if (error.response) {
      // Server responded with error status
      return {
        isValid: false,
        error: {
          code: 'AIR_PORTAL_API_ERROR',
          message: `Air Portal API error: ${error.response.status} - ${error.response.statusText}`
        }
      };
    }
    
    if (error.request) {
      // Request was made but no response received
      return {
        isValid: false,
        error: {
          code: 'AIR_PORTAL_SERVICE_UNAVAILABLE',
          message: 'Air Portal service is not responding'
        }
      };
    }
    
    // Something else happened
    return {
      isValid: false,
      error: {
        code: 'UNKNOWN_ERROR',
        message: 'Unknown error during Air Portal token validation'
      }
    };
  }
}

/**
 * Optional: Middleware to check specific permissions
 * @param {Array} requiredPermissions - Array of required permissions
 * @returns {Function} Middleware function
 */
function requirePermissions(requiredPermissions = []) {
  return async function(request, reply, done) {
    try {
      // Check if user has required permissions
      const userPermissions = request.user?.permissions || [];
      
      const hasPermission = requiredPermissions.every(permission => 
        userPermissions.includes(permission)
      );
      
      if (!hasPermission) {
        return reply.code(403).send({
          success: false,
          message: 'Insufficient permissions',
          error: 'INSUFFICIENT_PERMISSIONS',
          required: requiredPermissions,
          userPermissions: userPermissions
        });
      }
      
      done();
    } catch (error) {
      console.error('Permission check error:', error);
      return reply.code(500).send({
        success: false,
        message: 'Error checking permissions',
        error: 'PERMISSION_CHECK_ERROR'
      });
    }
  };
}

/**
 * Optional: Middleware to check specific roles
 * @param {Array} allowedRoles - Array of allowed roles
 * @returns {Function} Middleware function
 */
function requireRoles(allowedRoles = []) {
  return async function(request, reply, done) {
    try {
      const userRole = request.user?.role;
      
      if (!allowedRoles.includes(userRole)) {
        return reply.code(403).send({
          success: false,
          message: 'Access denied for your role',
          error: 'ROLE_ACCESS_DENIED',
          required: allowedRoles,
          userRole: userRole
        });
      }
      
      done();
    } catch (error) {
      console.error('Role check error:', error);
      return reply.code(500).send({
        success: false,
        message: 'Error checking role',
        error: 'ROLE_CHECK_ERROR'
      });
    }
  };
}

module.exports = {
  ssoTokenMiddleware,
  requirePermissions,
  requireRoles
};
