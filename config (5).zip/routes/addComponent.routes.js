const { addComponentController } = require('../controllers/controller.addComponent');
const { ssoTokenMiddleware } = require('../middleware/middleware.sso');

async function addComponentRoutes(fastify, options) {
  // Protected route - requires SSO token
  fastify.post('/api/add-component', {
    preHandler: ssoTokenMiddleware
  }, addComponentController);
}

module.exports = addComponentRoutes;
