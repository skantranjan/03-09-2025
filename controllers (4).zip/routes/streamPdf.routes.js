const { streamPdfController } = require('../controllers/controller.streamPdf');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

async function streamPdfRoutes(fastify, options) {
  // Handle CORS preflight requests
  fastify.options('/api/stream-pdf/:agreementId', async (request, reply) => {
    reply.header('Access-Control-Allow-Origin', process.env['FRONTEND-URL'] || 'http://localhost:5000');
    reply.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
    reply.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-apikey, Origin, requestid, timestamp');
    reply.code(204).send();
  });

  // Protected route - requires Bearer token
  // Stream PDF file from Azure Blob Storage
  fastify.get('/api/stream-pdf/:agreementId', {
    preHandler: bearerTokenMiddleware
  }, streamPdfController);
}

module.exports = streamPdfRoutes;
